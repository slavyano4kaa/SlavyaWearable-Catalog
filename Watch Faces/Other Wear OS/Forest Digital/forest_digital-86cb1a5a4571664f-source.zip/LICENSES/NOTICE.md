# Third-party notices

このプロジェクトは以下のオープンソースフォントを同梱しています。

## Sora

- 著作権: 2019 The Sora Project Authors
- 配布元: https://github.com/sora-xor/sora-font
- ライセンス: SIL Open Font License 1.1 — [`OFL-Sora.txt`](./OFL-Sora.txt)
- 同梱ファイル:
  - `watchface/src/main/res/font/sora_thin.ttf`
  - `watchface/src/main/res/font/sora_light.ttf`
  - `watchface/src/main/res/font/sora_semibold.ttf`
  - `watchface/src/main/res/font/sora_bold.ttf`

## JetBrains Mono

- 著作権: 2020 The JetBrains Mono Project Authors
- 配布元: https://github.com/JetBrains/JetBrainsMono
- ライセンス: SIL Open Font License 1.1 — [`OFL-JetBrainsMono.txt`](./OFL-JetBrainsMono.txt)
- 同梱ファイル:
  - `watchface/src/main/res/font/jetbrains_mono_medium.ttf`
