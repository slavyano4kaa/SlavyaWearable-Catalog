"""Small, explicit compatibility repairs on our resource copy, never on upstreams."""
import xml.etree.ElementTree as ET

def normalize(resources,repairs):
    changes=[]
    for path in sorted((resources/'raw').glob('*.xml')):
        parser=ET.XMLParser(target=ET.TreeBuilder(insert_comments=True))
        tree=ET.parse(path,parser=parser);root=tree.getroot();changed=False
        names={e.get('name') for e in root.iter('Group') if e.get('name')};group_number=0
        for node in root.iter():
            if 'strokeWidth' in repairs and node.tag=='Stroke' and 'width' in node.attrib:
                node.set('thickness',node.attrib.pop('width'));changed=True
            if 'groupNames' in repairs and node.tag=='Group' and 'name' not in node.attrib:
                while 'adapted_group_'+str(group_number) in names:group_number+=1
                name='adapted_group_'+str(group_number);node.set('name',name);names.add(name);changed=True
            if 'textAlignment' in repairs and node.tag=='PartText' and 'align' in node.attrib:
                alignment=node.attrib.pop('align')
                text=node.find('Text')
                if text is None:raise ValueError('PartText alignment has no Text target')
                text.set('align',alignment);changed=True
            if 'textVerticalCenter' in repairs and node.tag=='Text' and node.get('verticalAlign')=='CENTER':
                node.attrib.pop('verticalAlign');changed=True
            if 'resourceNames' in repairs:
                for key,value in list(node.attrib.items()):
                    if key in ['resource','family'] and value.startswith(('@drawable/','@font/')):
                        node.set(key,value.split('/',1)[1]);changed=True
            if 'literalTemplates' in repairs:
                for child in list(node):
                    if child.tag=='Template' and not len(child):
                        node.text=(node.text or '')+(child.text or '')
                        node.remove(child);changed=True
            if 'variantOrder' in repairs and node.tag=='TimeText':
                variants=[child for child in node if child.tag=='Variant']
                for child in variants:node.remove(child)
                for index,child in enumerate(variants):node.insert(index,child)
                changed=changed or bool(variants)
        if changed:
            tree.write(path,encoding='utf-8',xml_declaration=True)
            changes.append(path.name)
    return changes
