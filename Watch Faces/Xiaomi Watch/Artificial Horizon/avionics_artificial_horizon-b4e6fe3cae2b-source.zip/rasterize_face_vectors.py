"""SPDX-License-Identifier: MIT
Convert static Android vector assets to WFF-compatible PNGs without redrawing.
Original vector paths are retained next to the prepared source resources.
"""
from pathlib import Path
import argparse,math,xml.etree.ElementTree as ET
ANDROID='{http://schemas.android.com/apk/res/android}'

def color(value):
    if value.startswith('@') or value.startswith('?'):raise ValueError('Vector has unresolved color resource')
    if value.startswith('#') and len(value)==9:return '#'+value[3:]+value[1:3]
    return value

def convert(path):
    root=ET.parse(path).getroot()
    if root.tag!='vector':return False
    if root.get(ANDROID+'tint'):raise ValueError('Vector tint requires explicit resolution')
    width=float(root.get(ANDROID+'viewportWidth'));height=float(root.get(ANDROID+'viewportHeight'))
    if not 0<width<=4096 or not 0<height<=4096:raise ValueError('Vector bounds')
    svg=ET.Element('svg',{'xmlns':'http://www.w3.org/2000/svg','width':str(width),'height':str(height),'viewBox':f'0 0 {width} {height}'})
    def children(source,target):
        for element in source:
            if element.tag=='group':
                value=lambda name,default:float(element.get(ANDROID+name,default))
                px,py=value('pivotX',0),value('pivotY',0)
                transform=f'translate({value("translateX",0)+px} {value("translateY",0)+py}) rotate({value("rotation",0)}) scale({value("scaleX",1)} {value("scaleY",1)}) translate({-px} {-py})'
                children(element,ET.SubElement(target,'g',{'transform':transform}))
            elif element.tag=='path':
                if any(element.get(ANDROID+k) for k in ['trimPathStart','trimPathEnd','trimPathOffset']):raise ValueError('Trimmed vector path needs a path-length renderer')
                if len(element):raise ValueError('Vector gradients require explicit conversion')
                attrs={'d':element.get(ANDROID+'pathData'),'fill':color(element.get(ANDROID+'fillColor','#00000000')),'fill-opacity':element.get(ANDROID+'fillAlpha','1'),'fill-rule':'evenodd' if element.get(ANDROID+'fillType')=='evenOdd' else 'nonzero'}
                for original,svg_key in [('strokeColor','stroke'),('strokeWidth','stroke-width'),('strokeAlpha','stroke-opacity'),('strokeLineCap','stroke-linecap'),('strokeLineJoin','stroke-linejoin'),('strokeMiterLimit','stroke-miterlimit')]:
                    value=element.get(ANDROID+original)
                    if value is not None:attrs[svg_key]=color(value) if original=='strokeColor' else value
                ET.SubElement(target,'path',attrs)
            else:raise ValueError('Unsupported vector element '+element.tag)
    children(root,svg)
    import cairosvg
    return cairosvg.svg2png(bytestring=ET.tostring(svg),output_width=math.ceil(width),output_height=math.ceil(height))

def rasterize(directory):
    originals=directory.parent/'vector-sources';count=0
    for path in sorted(directory.glob('drawable*/*.xml')):
        png=convert(path)
        if png is False:continue
        was_generated=(originals/path.name).is_file()
        destination=directory/'drawable-nodpi'/path.with_suffix('.png').name
        destination.parent.mkdir(exist_ok=True)
        if destination.exists() and not was_generated:raise ValueError('Vector output collides with existing raster')
        originals.mkdir(exist_ok=True);(originals/path.name).write_bytes(path.read_bytes())
        destination.write_bytes(png);path.unlink();count+=1
    return count
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('resources',type=Path);args=parser.parse_args();print('Rasterized',rasterize(args.resources),'original vector assets')
